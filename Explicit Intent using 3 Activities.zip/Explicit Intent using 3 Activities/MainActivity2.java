package com.example.practical2c;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
TextView textView;
Button button2;
EditText rollno;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView= findViewById(R.id.textView);
        Intent intent = getIntent();
        String msg1 = intent.getStringExtra("Message");
        int msg = (Integer.parseInt(msg1)*100)/500;
        textView.setText("Percent : "+msg);
        rollno= findViewById(R.id.rollno);

        button2=findViewById(R.id.button);
        button2.setOnClickListener(v -> {
            String rollNo = rollno.getText().toString();
            String percent = String.valueOf(msg);
            Intent i = new Intent(this, MainActivity3.class);
            i.putExtra("RollNo",rollNo);
           i.putExtra("Percentage",percent);
            startActivity(i);
        });
    }
}