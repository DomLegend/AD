package com.example.practical2c;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText value;
    Button button1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        value = findViewById(R.id.value);
        button1=findViewById(R.id.button1);

        button1.setOnClickListener(v -> {
            String msg =value.getText().toString();
            Intent intent = new Intent(this, MainActivity2.class);
            intent.putExtra("Message",msg);
            startActivity(intent);
        });


    }
}