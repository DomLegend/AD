package com.example.prac5;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class SecondActivity extends AppCompatActivity {
    private TextView nameValueTextView, jobValueTextView, genderValueTextView,
            qualificationValueTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        nameValueTextView = findViewById(R.id.nameValueTextView);
        jobValueTextView = findViewById(R.id.jobValueTextView);
        genderValueTextView = findViewById(R.id.genderValueTextView);
        qualificationValueTextView = findViewById(R.id.qualificationValueTextView);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String jobtitle = intent.getStringExtra("jobtitle");
        String gender = intent.getStringExtra("gender");
        String qualification = intent.getStringExtra("qualification");
        nameValueTextView.setText(name);
        jobValueTextView.setText(jobtitle);
        genderValueTextView.setText(gender);
        qualificationValueTextView.setText(qualification);
    }
}

