package com.example.prac5;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    private EditText nameEditText;
    private Spinner jobSpinner;
    private RadioGroup genderRadioGroup;
    private RadioButton maleRadioButton, femaleRadioButton;
    private CheckBox matricCheckBox, diplomaCheckBox, bachelorCheckBox,
            mastersCheckBox;
    private Button registerButton;
    private String name, jobtitle, gender, qualification;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameEditText = findViewById(R.id.nameEditText);
        jobSpinner = findViewById(R.id.jobSpinner);
        List<String> subjects = new ArrayList<>();
        subjects.add("Manager");
        subjects.add("Waiter/Help Desk");
        subjects.add("Cook/Chef");
        subjects.add("Cleaning Services");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, subjects);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jobSpinner.setAdapter(adapter);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        maleRadioButton = findViewById(R.id.maleRadioButton);
        femaleRadioButton = findViewById(R.id.femaleRadioButton);
        matricCheckBox = findViewById(R.id.marticulationCheckBox);
        diplomaCheckBox = findViewById(R.id.diplomaCheckBox);
        bachelorCheckBox = findViewById(R.id.bachelorsCheckBox);
        mastersCheckBox = findViewById(R.id.mastersCheckBox);
        registerButton = findViewById(R.id.registerButton);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra("name", name);
                    intent.putExtra("jobtitle", jobtitle);
                    intent.putExtra("gender", gender);
                    intent.putExtra("qualification", qualification);
                    startActivity(intent);
                }
            }
        });
    }
    private boolean validate() {
        name = nameEditText.getText().toString().trim();
        jobtitle = jobSpinner.getSelectedItem().toString();
        gender = maleRadioButton.isChecked() ? "Male" : "Female";
        qualification = "";
        if (matricCheckBox.isChecked()) {
            qualification += "12th Pass";
        }
        if (diplomaCheckBox.isChecked()) {
            qualification += "Diploma";
        }
        if (bachelorCheckBox.isChecked()) {
            qualification += "Bachelors Degree";
        }
        if (mastersCheckBox.isChecked()) {
            qualification += "Masters Degree";
        }
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (qualification.isEmpty()) {
            Toast.makeText(this, "Please select your qualification",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
