package com.example.practical3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button fillData;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fillData=findViewById(R.id.fillData);
        fillData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager managerfrag = getSupportFragmentManager();
                FragmentTransaction transactionfrag = managerfrag.beginTransaction();
                transactionfrag.add(R.id.framefrag1,new Fragment1());
                transactionfrag.addToBackStack(null);
                transactionfrag.commit();
            }
        });



    }
}