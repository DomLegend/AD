package com.example.practical3;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link} factory method to
 * create an instance of this fragment.
 */
public class Fragment2 extends Fragment {
    View view;
    TextView maild , named , phoneno;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_2, container, false);

        Bundle bundle =this.getArguments();
        String name = bundle.getString("Name");
        String phone = bundle.getString("Phone");
        String mail = bundle.getString("Mail");

        named = view.findViewById(R.id.namedisplay);
        phoneno =view.findViewById(R.id.phonenumberdisplay);
        maild = view.findViewById(R.id.maildisplay);

        named.setText("Your Name is: "+name);
        phoneno.setText("PhoneNumber: "+phone);
        maild.setText("Mail ID: "+mail);

        return view;
    }
}