package com.example.practical3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {
Button displaybut ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        Bundle bund = new Bundle();

        String name = intent.getStringExtra("Name");
        String phone = intent.getStringExtra("Phone");
        String mail = intent.getStringExtra("Mail");
        bund.putString("Name",name);
        bund.putString("Phone",phone);
        bund.putString("Mail",mail);

        Fragment2 frag2 = new Fragment2();
        frag2.setArguments(bund);

        displaybut= findViewById(R.id.showData);
        displaybut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.add(R.id.framefrag2,frag2);
                ft.commit();
            }
        });

    }
}