package com.example.sharedata;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText txt1,txt2;
    private CheckBox cokebox,fantabox,spritebox;
    String str,drinks,mainc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.button);
        txt1 = findViewById(R.id.editText);
        txt2 = findViewById(R.id.editText1);
        cokebox = findViewById(R.id.checkBox);
        spritebox = findViewById(R.id.checkBox2);
        fantabox = findViewById(R.id.checkBox3);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                        str = txt1.getText().toString();
                        mainc = txt2.getText().toString();
                        Intent intent = new Intent(getApplicationContext(),second.class);
                        intent.putExtra("message",str);
                        intent.putExtra("mainc",mainc);
                        intent.putExtra("drinks",drinks);
                        startActivity(intent);

                }

            }
        });
    }
    private boolean validate(){
        drinks="";
        if(cokebox.isChecked()){
            drinks+="coke";
        }
        else if (spritebox.isChecked()){
            drinks+="sprite";
        }
        else if(fantabox.isChecked()){
            drinks+="fanta";
        }
        return true;

    }

}