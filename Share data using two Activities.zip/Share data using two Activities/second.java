package com.example.sharedata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class second extends AppCompatActivity {
    TextView msg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        msg = findViewById(R.id.textView4);
        Intent intent = getIntent();
        String str = intent.getStringExtra("message");
        String str1 = intent.getStringExtra("mainc");
        String str2 = intent.getStringExtra("drinks");
        msg.setText("The order has Main Course :"+str+ " and side dish of :"+str1+ " with "  +str2+"as drinks");

    }
}