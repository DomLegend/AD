package com.example.practical10;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
ImageButton swiggy , zomato , amazon ,bookmyshow;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swiggy=(ImageButton) findViewById(R.id.imageButton);
        zomato=(ImageButton)findViewById(R.id.imageButton2);
        amazon=(ImageButton)findViewById(R.id.imageButton3);
        bookmyshow=(ImageButton)findViewById(R.id.imageButton4);

        swiggy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String urlpass = "https://www.swiggy.com/";
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                intent.putExtra("URL",urlpass);
                startActivity(intent);

            }
        });

        zomato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String urlpass = "https://www.zomato.com/india";
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                intent.putExtra("URL",urlpass);
                startActivity(intent);

            }
        });

        amazon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String urlpass = "https://www.amazon.in/";
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                intent.putExtra("URL",urlpass);
                startActivity(intent);

            }
        });

        bookmyshow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String urlpass = "https://in.bookmyshow.com/";
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                intent.putExtra("URL",urlpass);
                startActivity(intent);

            }
        });

    }
}