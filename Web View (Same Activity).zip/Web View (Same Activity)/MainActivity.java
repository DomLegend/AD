package com.example.practical11;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
WebView webv;
Button showb;
EditText urls;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showb=findViewById(R.id.showb);
        urls=findViewById(R.id.enterurl);
        webv=findViewById(R.id.webView);

        showb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = urls.getText().toString();
                webv.setWebViewClient(new WebViewClient());
                webv.loadUrl(url);
                WebSettings webs = webv.getSettings();
                webs.setJavaScriptEnabled(true);
            }
        });
    }
}